#!/bin/bash

touch index.txt.attr

openssl genrsa -out private/ca.key 4096
openssl req -sha256 -new -nodes -key private/ca.key -days 1000 -out requests/ca.crs -config openssl.cnf -subj "/C=BA/ST=RS/L=Banja Luka/O=ETF/OU=KIRZ/CN=Pavle Vignjevic/emailAddress=pavle.vignjevic@student.etf.unibl.org"
openssl ca -selfsign -in requests/ca.crs -out ca.crt -keyfile private/ca.key -config openssl.cnf

openssl req -new -newkey rsa:4096 -sha256 -days 1000 -nodes -keyout private/private1.key -out requests/r_cert1.crt -config openssl.cnf -subj "/C=BA/ST=RS/L=Banja Luka/O=ETF/OU=KIRZ/CN=Korisnik1/emailAddress=korisnik1@kirz.com"
openssl req -new -newkey rsa:4096 -sha256 -days 1000 -nodes -keyout private/private2.key -out requests/r_cert2.crt -config openssl.cnf -subj "/C=BA/ST=RS/L=Banja Luka/O=ETF/OU=KIRZ/CN=Korisnik2/emailAddress=korisnik2@kirz.com"
openssl req -new -newkey rsa:4096 -sha256 -days 1000 -nodes -keyout private/private3.key -out requests/r_cert3.crt -config openssl.cnf -subj "/C=BA/ST=RS/L=Banja Luka/O=ETF/OU=KIRZ/CN=Korisnik3/emailAddress=korisnik3@kirz.com"
openssl req -new -newkey rsa:4096 -sha256 -days 1000 -nodes -keyout private/private4.key -out requests/r_cert4.crt -config openssl.cnf -subj "/C=BA/ST=RS/L=Banja Luka/O=ETF/OU=KIRZ/CN=Korisnik4/emailAddress=korisnik4@kirz.com"
openssl req -new -newkey rsa:4096 -sha256 -days 1000 -nodes -keyout private/private5.key -out requests/r_cert5.crt -config openssl.cnf -subj "/C=BA/ST=RS/L=Banja Luka/O=ETF/OU=KIRZ/CN=Korisnik5/emailAddress=korisnik5@kirz.com"

openssl pkcs8 -topk8 -inform PEM -outform DER -in private/private1.key -out private/private1.der -nocrypt
openssl pkcs8 -topk8 -inform PEM -outform DER -in private/private2.key -out private/private2.der -nocrypt
openssl pkcs8 -topk8 -inform PEM -outform DER -in private/private3.key -out private/private3.der -nocrypt
openssl pkcs8 -topk8 -inform PEM -outform DER -in private/private4.key -out private/private4.der -nocrypt
openssl pkcs8 -topk8 -inform PEM -outform DER -in private/private5.key -out private/private5.der -nocrypt

openssl ca -in requests/r_cert1.crt -config openssl.cnf -out newcerts/cert1.crt
openssl ca -in requests/r_cert2.crt -config openssl.cnf -out newcerts/cert2.crt
openssl ca -in requests/r_cert3.crt -config openssl.cnf -out newcerts/cert3.crt
openssl ca -in requests/r_cert4.crt -config openssl.cnf -out newcerts/cert4.crt
openssl ca -in requests/r_cert5.crt -config openssl.cnf -out newcerts/cert5.crt

openssl ca -config openssl.cnf -gencrl -out crl/crl.pem
openssl ca -config openssl.cnf -revoke newcerts/cert5.crt -crl_reason keyCompromise
openssl ca -config openssl.cnf -gencrl -out crl/crl.pem